package com.example.wanderlust;

public class User {
    public String email,name,phone_no;

    public User(){

    }
    public User(String name,String phone_no,String email){
        this.name=name;
        this.phone_no=phone_no;
        this.email=email;
    }
}
